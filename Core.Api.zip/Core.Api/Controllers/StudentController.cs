﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using Core.Model;
using System.Net.Http;
using System.Web.Http;
using Core.Api.Models.Dtos;
using System.Data.Entity;
using Core.Api.Filter;
using System.Globalization;

namespace Core.Api.Controllers
{
    [BasicAuthentication]
    public class StudentController : BaseApiController
    {
        [HttpGet]
        [Route("api/GetStudentsParents")]
        public HttpResponseMessage GetStudentsParents()
        {
            List<Student> student = _db.Stuednts.Include(a => a.Grade).Include(a => a.Group).Where(a => a.ParentId == CurrentClientId  && a.GroupId != null).ToList();
            return Request.CreateResponse(HttpStatusCode.OK, student.Select(a => new StudentsDto
            {
                studentId = a.StudentId,
                Name = a.Name,
                Email = a.Email,
                Image = a.Image,
                BirthDate = a.BirthDate,
                UserName = a.UserName,
                Phone = a.Phone,
                GroupName = a.Group?.Name,
                GrandName = a.Grade?.GradeName
            }).ToList());

        }

        [HttpGet]
        [Route("api/GetGroupSubjectByStudentId")]
        public HttpResponseMessage GetGroupSubjectByStudentId(int studentId)
        {
            Student student = _db.Stuednts.Find(studentId);
            int GroupId = student.GroupId.Value;
            var GroupSubject = _db.GroupSubjectTeachers.Include(a => a.Subject).Include(a => a.Teacher).Where(a => a.GroupId == GroupId).ToList();

            return Request.CreateResponse(HttpStatusCode.OK, new StudentSubjectDto
            {
                studentName = student.Name,
                StudentId = studentId,
                GroupId = GroupId,
                GroupName = _db.Groups.Find(GroupId)?.Name,
                
                subjectsDtos = GroupSubject.Select(a => new SubjectsDto
                {
                    SubjectId = a.SubjectId,
                    SubjectName = a.Subject.Name,
                    TeacherId = (int)a.TeacherId,
                    TeacherName = a.Teacher.Name,

                }).ToList()
            });
        }

        [HttpGet]
        [Route("api/GetStudentExams")]
        public HttpResponseMessage GetStudentExams(int StudentId , int SubjectId)
        {
            Student student = _db.Stuednts.Find(StudentId);
            var GroupSubject = _db.GroupSubjectTeachers.Include(a => a.Group).Include(a => a.Subject).Include(a => a.Teacher).FirstOrDefault(a => a.GroupId == (int)student.GroupId && a.SubjectId == SubjectId);
            StudentExamsDtos studentExams = new StudentExamsDtos()
            {
                GroupName = GroupSubject.Group?.Name,
                StudentName = student.Name,
                SubjectName = GroupSubject.Subject?.Name,
                TeacherId = (int)GroupSubject.Teacher.UserId,
                TeacherImage = GroupSubject.Teacher.Image  == null ? null : string.Concat(AdminUrl, GroupSubject.Teacher.Image),
                TeacherName = GroupSubject.Teacher.Name,
                TeacherInfo = GroupSubject.Teacher.Info,
                
            };


            return Request.CreateResponse(HttpStatusCode.OK, studentExams);
        }

        [HttpGet]
        [Route("api/StudentGroupTimeTaple")]
        public HttpResponseMessage StudentGroupTimeTaple(int StudentId,int DayNumber)
        {
            StudentTimeTableDto model = new StudentTimeTableDto();
            model.studentGroupTimeTapleList  = new List<StudentGroupTimeTapleDto>();
            List<int> Periodlist = new List<int>();

            Student student = _db.Stuednts.Find(StudentId);
            int GroupId = student.GroupId.Value;
            var GroupTimeTable = _db.GroupTimeTables.Include(a => a.Group).FirstOrDefault(a => a.GroupId == GroupId && a.Day == (WeekDay)DayNumber && a.IsWorking == true);

            //data
            //model.DayName = CultureInfo.GetCultureInfo("ar-EG").DateTimeFormat.GetDayName(DateTime.Parse(model.Date).DayOfWeek);
            if (DayNumber == 1)
                model.DayName = "السبت";
            else if (DayNumber == 2)
                model.DayName = "ألاحد";
            else if (DayNumber == 3)
                model.DayName = "الاتنين";
            else if (DayNumber == 4)
                model.DayName = "التلاتاء";
            else if (DayNumber == 5)
                model.DayName = "الاربعاء";
            else if (DayNumber == 6)
                model.DayName = "الخميس";
            else
                model.DayName = "الجمعة";


            if (GroupTimeTable != null)
            {
                if (GroupTimeTable.Period1 != null)
                    Periodlist.Add(GroupTimeTable.Period1.Value);

                if (GroupTimeTable.Period2 != null)
                    Periodlist.Add(GroupTimeTable.Period2.Value);

                if (GroupTimeTable.Period3 != null)
                    Periodlist.Add(GroupTimeTable.Period3.Value);
                if (GroupTimeTable.Period4 != null)
                    Periodlist.Add(GroupTimeTable.Period4.Value);

                foreach (var item in Periodlist)
                {
                    model.studentGroupTimeTapleList.Add(new StudentGroupTimeTapleDto
                    {
                        BranchName = _db.Branchs.Find(GroupTimeTable.Group.BranchId).Name,
                        subjectName = _db.GroupSubjectTeachers.Include(a => a.Subject).FirstOrDefault(a => a.GroupSubjectTeacherId == item).Subject.Name,
                        TeacherName = _db.GroupSubjectTeachers.Include(a => a.Teacher).FirstOrDefault(a => a.GroupSubjectTeacherId == item).Teacher.Name,
                        FromTime = GroupTimeTable.FromTime,
                        ToTime = GroupTimeTable.ToTime
                    });

                }
                return Request.CreateResponse(HttpStatusCode.OK, model);
            }
            else
                return Request.CreateResponse(HttpStatusCode.OK, new { RCode = -1, Message = currentLang == "ar" ? "هذا اليوم ليس من ضمن عمل ايام المجموعة" : " This Day is not belong Group Work Days" , DayName = model.DayName});

        }

        [HttpGet]
        [Route("api/GetStudentFees")]
        public HttpResponseMessage GetStudentFees(int studentId)
        {
            List<int> ListofMonth = new List<int>() {8, 9, 10,11,12,1,2,3,4,5};
            List<StudentAbsenceDto> studentAbsenceList = new List<StudentAbsenceDto>();

            var StudentPayment = _db.Payments.Where(a => a.StudentId == studentId && a.DateCreated.Year == DateTime.Now.Year).ToList();
            List<int> PayMonth = StudentPayment.Select(a => a.Month).ToList();
            foreach (var item in ListofMonth)
            {
                    if (PayMonth.Contains(item))
                    {
                        studentAbsenceList.Add(new StudentAbsenceDto()
                        {
                            MonthName = CultureInfo.GetCultureInfo("ar-EG").DateTimeFormat.GetAbbreviatedMonthName(item),
                            FeesMount = StudentPayment.FirstOrDefault(a => a.Month == item).Paid,
                            IsPayed = true,
                            PaymentDate = StudentPayment.FirstOrDefault(a => a.Month == item).DateCreated.ToShortDateString(),
                            Message = currentLang == "ar" ? "تم الدفع" : "Payed"

                        });
                    }
                    else
                    {
                        studentAbsenceList.Add(new StudentAbsenceDto()
                        {
                            MonthName = CultureInfo.GetCultureInfo("ar-EG").DateTimeFormat.GetAbbreviatedMonthName(item),
                            IsPayed = false,
                            Message = currentLang == "ar" ? "لم يتم الدفع بعد" : "Not Payed"

                        });
                    }

            }
            return Request.CreateResponse(HttpStatusCode.OK, studentAbsenceList);
        }
        [HttpGet]
        [Route("api/GetTeacherInfo")]
        public HttpResponseMessage GetTeacherInfo(int TeacherId)
        {
            var groupSubjectTeachers = _db.GroupSubjectTeachers.Include(a => a.Teacher).Include(a => a.Subject).FirstOrDefault(a => a.TeacherId == TeacherId && a.Teacher.IsDeleted != true);

            User Teacher = groupSubjectTeachers.Teacher;
            int SubjectId = groupSubjectTeachers.SubjectId;
            string SubjectName = groupSubjectTeachers.Subject.Name;
            int GroupId = groupSubjectTeachers.GroupId;

            List<string> BranchNames  = _db.GroupSubjectTeachers.Include(a => a.Group).Where(a => a.TeacherId == TeacherId).Select(a => a.Group).Include(a => a.Branch).Select(a => a.Name).ToList();

            TeacherInfoDto teacherInfoDto = new TeacherInfoDto()
            {
                TeacherId = (int)Teacher.UserId,
                TeacherName = Teacher.Name,
                Email = Teacher.Email,
                Image = Teacher.Image == null ? null : string.Concat(AdminUrl, Teacher.Image),
                phone = Teacher.Phone,
                TeacherExperience = Teacher.Experince,
                TeacherInfo = Teacher.Info,
                BranchName = BranchNames,
                BranchAddress = _db.Groups.Include(a => a.Branch).FirstOrDefault(a => a.GroupId == GroupId).Branch.Address,
                SubjectName = SubjectName,
            };
            return Request.CreateResponse(HttpStatusCode.OK, teacherInfoDto);
        }

        [HttpGet]
        [Route("api/GetStudentAbcense")]
        public HttpResponseMessage GetStudentAbcense(int StudentId , int MonthId , int Year)
        {
            AttendanceDto attendanceModel = new AttendanceDto();
            attendanceModel.abcense = new List<StudentAbcenseDtos>();
            //get days of month
            var listOfDatesInMonth = GetDates(Year, MonthId);
            //get list of student attendance
            var StudentAttendance = _db.Attendances.Include(a => a.Student).Where(a => a.StudentId == StudentId && a.Student.IsDeleted != true).ToList();
            //get Count of abcence and attendance
            //attendanceModel.AbcenceCount = StudentAttendance.Where(a => a.Type == AttendType.Absence).Count();
            //attendanceModel.AttendCount = StudentAttendance.Where(a => a.Type == AttendType.Attend).Count();
            //get dates of student Attendance
            var StudentAttendanceDate = StudentAttendance.Select(a => a.Date.ToShortDateString()).ToList();
            //get groupId by StudentId
            int GroupId = _db.Stuednts.Find(StudentId).GroupId.Value;
            //get days of GroupTime Table 
            var GroupDayNameWork = _db.GroupTimeTables.Where(a => a.GroupId == GroupId && a.IsWorking == true).Select(a => (int)a.Day).ToList();
            foreach (var date in listOfDatesInMonth)
            {

                int DayNum = ((int)(DateTime.Parse(date).DayOfWeek + 2) % 7) == 0 ? 7 : (int)(DateTime.Parse(date).DayOfWeek + 2) % 7; // Saturday start

                // this day is work day and take student attend in it 
                if (StudentAttendanceDate.Contains(date) && GroupDayNameWork.Contains(DayNum))
                {
                    attendanceModel.abcense.Add(new StudentAbcenseDtos
                    {
                        Date = date,
                        IsAttend = (int)StudentAttendance.FirstOrDefault(a => a.Date.ToShortDateString() == date).Type,
                        AbsenceReason = StudentAttendance.FirstOrDefault(a => a.Date.ToShortDateString() == date).AbsenceReason,
                        IsWorkingDay = true
                    });

                    if (StudentAttendance.FirstOrDefault(a => a.Date.ToShortDateString() == date).Type == AttendType.Absence)
                        attendanceModel.AbcenceCount++;
                    else
                        attendanceModel.AttendCount++;
                }
                else if(!StudentAttendanceDate.Contains(date) && GroupDayNameWork.Contains(DayNum))
                {
                    // this day is from work day but not take student attend in it
                    attendanceModel.abcense.Add(new StudentAbcenseDtos
                    {
                        Date = date,
                        IsAttend = 0,
                        IsWorkingDay = true
                    });
                }
                else
                {
                    // this day not from work day 
                    attendanceModel.abcense.Add(new StudentAbcenseDtos
                    {
                        Date = date,
                        IsAttend = 0,
                        IsWorkingDay = false
                    });
                }
            }
            return Request.CreateResponse(HttpStatusCode.OK, attendanceModel);
        }
    }
}
