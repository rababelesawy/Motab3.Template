﻿using Core.Model;
using Core.Model.ViewModels.User;
using Core.Service;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Core.Api.Controllers
{
    public class ExamsController : BaseApiController
    {
        private readonly IExamService _examservice;

        public ExamsController()
        {

        }
        public ExamsController(IExamService examservice)
        {
            _examservice = examservice;

        }

        [HttpGet]
        [Route("api/GetExamQuestions")]
        public HttpResponseMessage GetExamQuestions(int id)
        {
            var exam = _db.Exams.FirstOrDefault(e => e.ExamId == id);

            if (exam == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            var questions = _db.Questions
                                  .Where(q => q.ExamId == id)
                                  .Select(q => new
                                  {
                                      q.QuestionId,
                                      q.Answer1,
                                      q.Answer2,
                                      q.Answer3,
                                      q.Answer4,
                                  })
                                  .ToList();

            var response = new
            {
                TotalExamTimeInMinutes = exam.TotalTime,
                Questions = questions
            };

            return Request.CreateResponse(HttpStatusCode.OK, response);
        }



        [HttpPost]
        [Route("api/SaveExam")]
        public HttpResponseMessage SaveExam([FromBody] SaveExamModel request)
        {
            if (request.QuestionIds == null || request.AnswerIds == null || request.QuestionIds.Count != request.AnswerIds.Count)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, "Invalid question or answer list");
            }

            var exam = _db.Exams.FirstOrDefault(e => e.ExamId == request.ExamId);
            if (exam == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            var questions = _db.Questions.Where(q => q.ExamId == request.ExamId && request.QuestionIds.Contains(q.QuestionId)).ToList();
            if (questions.Count != request.QuestionIds.Count)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, "Some questions are not found in the exam");
            }

            int totalScore = 0;
            for (int i = 0; i < request.QuestionIds.Count; i++)
            {
                var question = questions.FirstOrDefault(q => q.QuestionId == request.QuestionIds[i]);
                if (question == null)
                {
                    return Request.CreateResponse(HttpStatusCode.BadRequest, "Question not found.");
                }

                if (question.RightAnswer == request.AnswerIds[i])
                {
                  
                    totalScore += 1;
                }
            }

           
            var studentExam = new StudentExam
            {
                ExamId = request.ExamId,
                FinalDegree = totalScore,
                Date = DateTime.Now
            };
            _db.StudentExams.Add(studentExam);
            _db.SaveChanges();

            for (int i = 0; i < request.QuestionIds.Count; i++)
            {
                var studentExamResult = new StudentExamResult
                {
                    StudentExamId = studentExam.StudentExamId,
                    QuestionId = request.QuestionIds[i],
                    SelectedAnswer = request.AnswerIds[i]
                };
                _db.ExamResults.Add(studentExamResult);
            }
            _db.SaveChanges();

            return Request.CreateResponse(HttpStatusCode.OK, new { Score = totalScore });
        }


    }
}
