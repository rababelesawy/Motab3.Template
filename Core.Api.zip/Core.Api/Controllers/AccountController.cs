﻿using Core.Api.Models.Dtos;
using Core.Model;
using Core.Service;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Core.Api.Controllers
{
    [AllowAnonymous]
    public class AccountController : BaseApiController
    {

        //private readonly IParentService _parentService;
        //public AccountController(IParentService parentService)
        //{
        //    _parentService = parentService;
        //}

        private readonly string filePath = @"C:\Inetpub\vhosts\repoteq.com\api.educenter.repoteq.com\centers.json";
        [HttpGet]
        [Route("api/GetUrl")]
        public HttpResponseMessage GetUrl(string Code) { 
            List<CenterUrlDto> Centers = JsonConvert.DeserializeObject<List<CenterUrlDto>>(File.ReadAllText(filePath));
            var result = Centers.FirstOrDefault(p => p.code.Equals(Code));
            if(result == null)
                return Request.CreateResponse(HttpStatusCode.NotFound, new { RCode = -1, Message = "الرجاء ادخال كود السنتر صحيح"});
            else
            return Request.CreateResponse(HttpStatusCode.OK, result.url);
        }

        [HttpGet]
        [Route("api/GetCentersCode")]
        public HttpResponseMessage GetCentersCode()
        {
            List<CenterUrlDto> Centers = JsonConvert.DeserializeObject<List<CenterUrlDto>>(File.ReadAllText(filePath));
            List<string> Codes = Centers.Select(a => a.code).ToList();
            return Request.CreateResponse(HttpStatusCode.OK, Codes);
        }


        [HttpPost]
        [Route("api/Login")]
        public HttpResponseMessage Login(LoginDto loginDto)
        {
            var Resulte = Authenticate(loginDto);
            return Request.CreateResponse(HttpStatusCode.OK, Resulte);
        }
        [HttpPost]
        [Route("api/ForgetPassword")]
        public HttpResponseMessage ForgetPassword(string phone)
        {

            Parent parent = _db.Parents.FirstOrDefault(a => a.Phone == phone);

            if (parent == null)
                return Request.CreateResponse(HttpStatusCode.NotFound, new { RCode = -1, message = currentLang == "ar" ? "هذا الرقم غير موجود" : "This Phone not Found" });

            string Otp = SendSMSOTP(parent.UserName, phone);
            parent.ActivationCode = Otp;
            _db.SaveChanges();
            return Request.CreateResponse(HttpStatusCode.OK, new { RCode = 1, Phone = phone, OTP = Otp,  message = currentLang == "ar" ? "تم ارسال الكود الخاص بك على الموبايل" : "The Otp Was Sent" });
        }
        [HttpGet]
        [Route("api/VerifyCode")]
        public HttpResponseMessage VerifyCode(string ActivationCode , string Phone)
        {
            string ParentOtp = _db.Parents.FirstOrDefault(a => a.Phone == Phone).ActivationCode;
            if (ParentOtp.Equals(ActivationCode))
                return Request.CreateResponse(HttpStatusCode.OK, new { RCode = 1, Message = "تم التأكد من ركز التفعيل" });
            else
                return Request.CreateResponse(HttpStatusCode.NotFound, new { RCode = -1, Message = "الرجاء التاكد من رمز التفعيل" });
        }

        [HttpPost]
        [Route("api/ResetPassword")]
        public HttpResponseMessage ResetPassword(ResetPasswordDto model)
        {
            Parent parent = _db.Parents.FirstOrDefault(a => a.Phone == model.Phone);

            if (parent == null)
                return Request.CreateResponse(HttpStatusCode.NotFound, new { RCode = -1, message = currentLang == "ar" ? "هذا الرقم غير موجود" : "This Phone not Found" });

            if (model.Newpassword == model.ConfirmNewpassword)
            {
                parent.Password = model.Newpassword;
                _db.SaveChanges();
            }
            else
                return Request.CreateResponse(HttpStatusCode.BadRequest, new { RCode = -1, message = currentLang == "ar" ? "الرجاء اعادة ادخال تاكيد كلمة المرور" : "Please Enter a Confirm Password Again" });

            return Login(new LoginDto { UserName = parent.UserName , Password = parent.Password});
        }
        #region method
        public TokenDto Authenticate(LoginDto model)
        {   
            //Parent user = _parentService.ValidateParent(model.UserName, model.Password);
            Parent user = _db.Parents.FirstOrDefault(a => a.UserName == model.UserName && a.Password == model.Password);
            if(user == null)
            {
                return new TokenDto { RCode = -1, Message = currentLang == "ar" ? "الرجاء التأكد من اسم المستخدم و كلمة المرور" : "Please verify your username and password" };
            }

            var parentdata = _db.Parents.Find(user.ParentId);

            return new TokenDto
            {
                RCode = 1,
                UserName = parentdata.UserName,
                Password = parentdata.Password,
                ImageUrl = parentdata.Image,
                Job = parentdata.Job,
                Age = parentdata.Age.Value,
                Name = parentdata.Name,
                Phone = parentdata.Phone,
                UserId = (int)parentdata.ParentId,
                Message = currentLang == "ar" ? "تم تسجيل الدخول بنجاح" : "Login Scuccess",
                Token = GenerateToken(model.UserName, model.Password)
            };
        }



            
        #endregion
    }
}
