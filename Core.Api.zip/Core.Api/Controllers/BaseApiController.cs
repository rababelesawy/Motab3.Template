﻿using Core.Data;
using Core.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Web.Http;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace Core.Api.Controllers
{
    public class BaseApiController : ApiController
    {

        //private IUserService userService;
        //private IRoleService roleService;

       public CoreEntities _db = new CoreEntities();

        public int CurrentClientId
        {
            get
            {
                return int.Parse(string.IsNullOrEmpty(Thread.CurrentPrincipal.Identity.Name) ? "0" : Thread.CurrentPrincipal.Identity.Name);
            }
        }

        public string currentLang
        {
            get
            {
                return Request.Headers.AcceptLanguage.Count > 0 ? Request.Headers.AcceptLanguage.FirstOrDefault().Value : "ar";
            }
        }

        public string AdminUrl
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["adminUrl"].ToString();
            }
        }

        public string GenerateToken(string UserName, string Password)
        {

            return Base64Encode(UserName + ":" + Password + ":" + DateTime.Now.AddDays(7).ToShortDateString());
        }
        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }
        public string SendSMSOTP(string parentName, string Phone)
        {

            string OTP = new Random().Next(0000, 9999).ToString();
            // Find your Account Sid and Auth Token at twilio.com/console
            const string accountSid = "ACcc9159f17319da03a6f2670b5d917fad";
            const string authToken = "a4b9e97c0bd27006022e45fe23ffcef0";


            //TwilioClient.Init(accountSid, authToken);

            //var to = new PhoneNumber(Phone);
            //var message = MessageResource.Create(
            //    to,
            //    from: new PhoneNumber("+19084708034"),
            //    body: $"Hello" + parentName + " This is OTP Code :" + OTP);

            return OTP;

        }


        public static List<string> GetDates(int year, int month)
        {
            var dates = new List<string>();

            // Loop from the first day of the month until we hit the next month, moving forward a day at a time
            for (var date = new DateTime(year, month, 1); date.Month == month; date = date.AddDays(1))
            {
                dates.Add(date.ToShortDateString());
            }

            return dates;
        }

       

    }
}
