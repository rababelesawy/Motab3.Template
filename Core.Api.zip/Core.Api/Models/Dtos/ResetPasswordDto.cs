﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Core.Api.Models.Dtos
{
    public class ResetPasswordDto
    {
        public string Phone { get; set; }
        [Required]
        public string Newpassword { get; set; }

        [Required]
        [Compare("Newpassword", ErrorMessage = "الرجاء ادخالتأكيد كلمة السر مرة اخرى !")]
        public string ConfirmNewpassword { get; set; }
        
    }
}