﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Core.Api.Models.Dtos
{
    public class StudentAbsenceDto
    {
        public string MonthName { get; set; }
        public bool IsPayed { get; set; }

        public decimal FeesMount { get; set; }


        public string PaymentDate { get; set; }

        public string Message { get; set; }
    }
}