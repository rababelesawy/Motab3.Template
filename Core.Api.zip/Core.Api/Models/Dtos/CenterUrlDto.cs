﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Core.Api.Models.Dtos
{
    public class CenterUrlDto
    {
        public string code { get; set; }
        public string url { get; set; }
    }
}