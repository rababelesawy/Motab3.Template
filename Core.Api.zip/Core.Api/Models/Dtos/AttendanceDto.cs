﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Core.Api.Models.Dtos
{
    public class AttendanceDto
    {
        public int AbcenceCount { get; set; }
        public int AttendCount { get; set; }
        public List<StudentAbcenseDtos> abcense { get; set; }
    }
}