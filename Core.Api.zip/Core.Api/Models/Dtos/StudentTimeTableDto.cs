﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Core.Api.Models.Dtos
{
    public class StudentTimeTableDto
    {
        public string DayName { get; set; }
        //public string Date { get; set; }
        public string FromTime { get; set; }
        public string ToTime { get; set; }

        public List<StudentGroupTimeTapleDto> studentGroupTimeTapleList { get; set; }
    }
}