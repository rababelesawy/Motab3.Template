﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Core.Api.Models.Dtos
{
    public class TokenDto
    {
        public int UserId { get; set; }
        public int RCode { get; set; }
        public string ImageUrl { get; set; }
        public string Phone { get; set; }
        public string Name { get; set; }
        public string Token { get; set; }
        public string Job { get; set; }
        public decimal Age { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Message { get; set; }
        public string Lang { get; set; }
    }
}