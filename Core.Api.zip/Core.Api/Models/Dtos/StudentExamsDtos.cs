﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Core.Api.Models.Dtos
{
    public class StudentExamsDtos
    {
        public string SubjectName { get; set; }
        public string StudentName { get; set; }
        public int TeacherId { get; set; }
        public string TeacherImage { get; set; }
        public string TeacherName { get; set; }
        public string TeacherInfo { get; set; }
        public string GroupName { get; set; }
    }
}