﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Core.Api.Models.Dtos
{
    public class StudentAbcenseDtos
    {
        public string Date { get; set; }
        public int IsAttend { get; set; }
        public bool IsWorkingDay { get; set; }
        public string AbsenceReason { get; set; }
    }
}