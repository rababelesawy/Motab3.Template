﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Core.Api.Models.Dtos
{
    public class StudentSubjectDto
    {
        public string studentName { get; set; }
        public int GroupId { get; set; }
        public string GroupName { get; set; }

        public int StudentId { get; set; }

        public List<SubjectsDto> subjectsDtos { get; set; }
      
    }
}