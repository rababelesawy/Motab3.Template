﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Core.Api.Models.Dtos
{
    public class TeacherInfoDto
    {
        public int TeacherId { get; set; }
        public string TeacherName { get; set; }
        public string SubjectName { get; set; }
        public string TeacherInfo { get; set; }
        public string Email { get; set; }
        public string phone { get; set; }
        public string Image { get; set; }
        public List<string> BranchName { get; set; }
        public int TeacherExperience { get; set; }
        public string BranchAddress { get; set; }


    }
}