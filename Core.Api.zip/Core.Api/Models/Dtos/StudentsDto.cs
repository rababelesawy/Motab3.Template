﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Core.Api.Models.Dtos
{
    public class StudentsDto
    {
        public long studentId { get; set; }
        public string Name { get; set; }
        public string Image { get; set; }

        public string Email { get; set; }
        public string Phone { get; set; }
        public string UserName { get; set; }
        public string BirthDate { get; set; }

        public string GroupName { get; set; }
        public string GrandName { get; set; }

    }


}